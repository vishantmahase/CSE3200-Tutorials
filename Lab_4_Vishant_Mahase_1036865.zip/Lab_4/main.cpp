#include <windows.h>
#include <GL/glu.h>
#include <GL/glut.h>
//Vishant Mahase-1036865
//CSE3200 lab 4


GLfloat Cx = 0, Cy = 0, Cz = 4;

void MyFunction()
{
    glClearColor(0,0,0,1);
    glEnable(GL_DEPTH_TEST);


    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-2,2,-2,2,0.1,100);
    glMatrixMode(GL_MODELVIEW);
}

void Square(GLfloat A[],GLfloat B[],GLfloat C[],GLfloat D[])
{
    glBegin(GL_POLYGON);
    glVertex3fv(A);
    glVertex3fv(B);
    glVertex3fv(C);
    glVertex3fv(D);
    glEnd();
}

void Cube(GLfloat V0[],
          GLfloat V1[],
          GLfloat V2[],
          GLfloat V3[],
          GLfloat V4[],
          GLfloat V5[],
          GLfloat V6[],
          GLfloat V7[])
          {
              glColor3f(1,0,0);
              Square(V0,V1,V2,V3);
              glColor3f(0,1,0);
              Square(V4,V5,V6,V7);
              glColor3f(0,0,1);
              Square(V0,V4,V7,V3);
              glColor3f(1,1,0);
              Square(V1,V5,V6,V2);
              glColor3f(1,0,1);
              Square(V2,V3,V7,V6);
              glColor3f(0,1,1);
              Square(V0,V1,V5,V4);
          }

      void Triangle(GLfloat A[], GLfloat B[], GLfloat C[]) {
    glBegin(GL_TRIANGLES);
        glVertex3fv(A);
        glVertex3fv(B);
        glVertex3fv(C);
    glEnd();
}

void DrawHouse() {
    GLfloat V[8][3] = {
        {-1.0f,  0.0f,  0.6f},
        { 1.0f,  0.0f,  0.6f},
        { 1.0f,  1.2f,  0.6f},
        {-1.0f,  1.2f,  0.6f},
        {-1.0f,  0.0f, -0.6f},
        { 1.0f,  0.0f, -0.6f},
        { 1.0f,  1.2f, -0.6f},
        {-1.0f,  1.2f, -0.6f},
    };

    glColor3f(0.91f, 0.76f, 0.57f);
    Square(V[0], V[1], V[2], V[3]);
    Square(V[5], V[4], V[7], V[6]);
    Square(V[4], V[0], V[3], V[7]);
    Square(V[1], V[5], V[6], V[2]);
    glColor3f(0.6f, 0.5f, 0.4f);
    Square(V[4], V[5], V[1], V[0]);

    glColor3f(0.36f, 0.20f, 0.09f);
    GLfloat D[4][3] = {
        {-0.18f, 0.0f,  0.61f},
        { 0.18f, 0.0f,  0.61f},
        { 0.18f, 0.60f, 0.61f},
        {-0.18f, 0.60f, 0.61f},
    };
    Square(D[0], D[1], D[2], D[3]);
    glColor3f(1.0f, 0.84f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex3f(0.14f, 0.30f, 0.62f);
    glEnd();

    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WL[4][3] = {
        {-0.75f, 0.55f, 0.61f},
        {-0.38f, 0.55f, 0.61f},
        {-0.38f, 0.95f, 0.61f},
        {-0.75f, 0.95f, 0.61f},
    };
    Square(WL[0], WL[1], WL[2], WL[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f(-0.75f, 0.55f, 0.62f); glVertex3f(-0.38f, 0.55f, 0.62f);
        glVertex3f(-0.38f, 0.95f, 0.62f); glVertex3f(-0.75f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(-0.565f, 0.55f, 0.62f); glVertex3f(-0.565f, 0.95f, 0.62f);
        glVertex3f(-0.75f,  0.75f, 0.62f); glVertex3f(-0.38f,  0.75f, 0.62f);
    glEnd();

    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WR[4][3] = {
        { 0.38f, 0.55f, 0.61f},
        { 0.75f, 0.55f, 0.61f},
        { 0.75f, 0.95f, 0.61f},
        { 0.38f, 0.95f, 0.61f},
    };
    Square(WR[0], WR[1], WR[2], WR[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f( 0.38f, 0.55f, 0.62f); glVertex3f( 0.75f, 0.55f, 0.62f);
        glVertex3f( 0.75f, 0.95f, 0.62f); glVertex3f( 0.38f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f( 0.565f, 0.55f, 0.62f); glVertex3f( 0.565f, 0.95f, 0.62f);
        glVertex3f( 0.38f,  0.75f, 0.62f); glVertex3f( 0.75f,  0.75f, 0.62f);
    glEnd();

    GLfloat RF[2][3] = { { 0.0f, 1.8f,  0.7f}, { 0.0f, 1.8f, -0.7f} };
    GLfloat RE[4][3] = {
        {-1.1f, 1.2f,  0.7f}, { 1.1f, 1.2f,  0.7f},
        { 1.1f, 1.2f, -0.7f}, {-1.1f, 1.2f, -0.7f},
    };
    glColor3f(0.72f, 0.19f, 0.15f);
    Square(RE[0], RE[3], RF[1], RF[0]);
    Square(RE[1], RE[2], RF[1], RF[0]);
    Triangle(RE[0], RE[1], RF[0]);
    Triangle(RE[3], RE[2], RF[1]);
}

void Draw()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(Cx, Cy, Cz,  // camera position
              0, 0, 0,      // look at center
              0, 1, 0);     // up direction
    glScalef(4.0f, 4.0f, 4.0f);
    DrawHouse();
    glutSwapBuffers();
}

void Key(unsigned char ch, int x, int y)
{
    switch(ch)
    {
        case 'x' : Cx = Cx - 0.5; break;
        case 'X' : Cx = Cx + 0.5; break;

        case 'y' : Cy = Cy - 0.5; break;
        case 'Y' : Cy = Cy + 0.5; break;

        case 'z' : Cz = Cz - 0.5; break;
        case 'Z' : Cz = Cz + 0.5; break;
    }
    glutPostRedisplay();
}

int main(int argC, char * argV[])
{
    glutInit(&argC,argV);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(100,150);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("House - Camera View");
    MyFunction();
    glutKeyboardFunc(Key);
    glutDisplayFunc(Draw);
    glutMainLoop();
    return 0;
}



