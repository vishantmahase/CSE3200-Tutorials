//Vishant Mahase
//1036865
//Spacebar-start/stop
//xyz- spin direction

#include<windows.h>
#include<GL/glu.h>
#include<GL/glut.h>
#include<math.h>

GLfloat d = 0;  //Rotation variable
int axis = 0; // 0=Z, 1=X, 2=Y
int spinning = 1;
void CustomFunction()
{
    glClearColor(0,0,0,1);
    glEnable(GL_DEPTH_TEST);        //Enables you to see the back face of a 3D Object
}

void Spin() {
    if (spinning) {
        d = d + 1;
        if (d > 360) d = 0;
        glutPostRedisplay();
    }
}

void Face(GLfloat A[],GLfloat B[], GLfloat C[],GLfloat D[])
{
    glBegin(GL_POLYGON);
        glVertex3fv(A);
        glVertex3fv(B);
        glVertex3fv(C);
        glVertex3fv(D);
    glEnd();
}

void Cube (GLfloat V0[],
           GLfloat V1[],
           GLfloat V2[],
           GLfloat V3[],
           GLfloat V4[],
           GLfloat V5[],
           GLfloat V6[],
           GLfloat V7[])
           {
               glColor3f(1,0,0);
               Face(V0,V1,V2,V3);    //Front Face
               glColor3f(0,1,0);
               Face(V4,V5,V6,V7);   //Back Face
               glColor3f(0,0,1);
               Face(V0,V4,V7,V3);   //Left Face
               glColor3f(1,1,0);
               Face(V1,V5,V6,V2);   //Right Face
               glColor3f(1,0,1);
               Face(V2,V3,V7,V6);   //Bottom Face
               glColor3f(0,1,1);
               Face(V0,V1,V5,V4);   //Top Face
           }

void Draw()
{
    GLfloat V[8][3] = {
                         {-0.5, 0.5, 0.5},
                         { 0.5, 0.5, 0.5},
                         { 0.5,-0.5, 0.5},
                         {-0.5,-0.5, 0.5},
                         {-0.5, 0.5,-0.5},
                         { 0.5, 0.5,-0.5},
                         { 0.5,-0.5,-0.5},
                         {-0.5,-0.5,-0.5},
    };

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    //Spinning the cube in the Z-axis
    GLfloat rV[8][3],r ;         //amount of degrees for rotation - represented by d

    //Convert degrees into radians
    r = d * 3.14/180;

    int i;

    //A for loop can be used to move through the array of points iteratively.
    for (i = 0; i < 8; i++)
    {
        if (axis == 0) { // Z-axis
            rV[i][0] = V[i][0] * cos(r) - V[i][1] * sin(r);
            rV[i][1] = V[i][0] * sin(r) + V[i][1] * cos(r);
            rV[i][2] = V[i][2];
        }
        else if (axis == 1) { // X-axis
            rV[i][0] = V[i][0];
            rV[i][1] = V[i][1] * cos(r) - V[i][2] * sin(r);
            rV[i][2] = V[i][1] * sin(r) + V[i][2] * cos(r);
        }
        else { // Y-axis
            rV[i][0] = V[i][0] * cos(r) + V[i][2] * sin(r);
            rV[i][1] = V[i][1];
            rV[i][2] = -V[i][0] * sin(r) + V[i][2] * cos(r);
        }
    }


    //The Cube function has to be updated with the new points for the render to reflect changes.
    Cube(rV[0],rV[1],rV[2], rV[3], rV[4], rV[5], rV[6], rV[7]);



    glutSwapBuffers();              //Pushes graphical code to the graphical window.
}

void Keyboard(unsigned char key, int x, int y) {
    if (key == 'x' || key == 'X') axis = 1;
    if (key == 'y' || key == 'Y') axis = 2;
    if (key == 'z' || key == 'Z') axis = 0;
    if (key == ' ') spinning = !spinning; //spacebar will pause and resume
}
void Triangle(GLfloat A[], GLfloat B[], GLfloat C[]) {
    glBegin(GL_TRIANGLES);
        glVertex3fv(A);
        glVertex3fv(B);
        glVertex3fv(C);
    glEnd();
}
void Reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (double)w / (double)h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void DrawHouse() {
    GLfloat V[8][3] = {
        {-1.0f,  0.0f,  0.6f},
        { 1.0f,  0.0f,  0.6f},
        { 1.0f,  1.2f,  0.6f},
        {-1.0f,  1.2f,  0.6f},
        {-1.0f,  0.0f, -0.6f},
        { 1.0f,  0.0f, -0.6f},
        { 1.0f,  1.2f, -0.6f},
        {-1.0f,  1.2f, -0.6f},
    };

    glColor3f(0.91f, 0.76f, 0.57f);
    Face(V[0], V[1], V[2], V[3]);
    Face(V[5], V[4], V[7], V[6]);
    Face(V[4], V[0], V[3], V[7]);
    Face(V[1], V[5], V[6], V[2]);
    glColor3f(0.6f, 0.5f, 0.4f);
    Face(V[4], V[5], V[1], V[0]);

    glColor3f(0.36f, 0.20f, 0.09f);
    GLfloat D[4][3] = {
        {-0.18f, 0.0f,  0.61f},
        { 0.18f, 0.0f,  0.61f},
        { 0.18f, 0.60f, 0.61f},
        {-0.18f, 0.60f, 0.61f},
    };
    Face(D[0], D[1], D[2], D[3]);
    glColor3f(1.0f, 0.84f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex3f(0.14f, 0.30f, 0.62f);
    glEnd();

    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WL[4][3] = {
        {-0.75f, 0.55f, 0.61f},
        {-0.38f, 0.55f, 0.61f},
        {-0.38f, 0.95f, 0.61f},
        {-0.75f, 0.95f, 0.61f},
    };
    Face(WL[0], WL[1], WL[2], WL[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f(-0.75f, 0.55f, 0.62f); glVertex3f(-0.38f, 0.55f, 0.62f);
        glVertex3f(-0.38f, 0.95f, 0.62f); glVertex3f(-0.75f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(-0.565f, 0.55f, 0.62f); glVertex3f(-0.565f, 0.95f, 0.62f);
        glVertex3f(-0.75f,  0.75f, 0.62f); glVertex3f(-0.38f,  0.75f, 0.62f);
    glEnd();

    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WR[4][3] = {
        { 0.38f, 0.55f, 0.61f},
        { 0.75f, 0.55f, 0.61f},
        { 0.75f, 0.95f, 0.61f},
        { 0.38f, 0.95f, 0.61f},
    };
    Face(WR[0], WR[1], WR[2], WR[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f( 0.38f, 0.55f, 0.62f); glVertex3f( 0.75f, 0.55f, 0.62f);
        glVertex3f( 0.75f, 0.95f, 0.62f); glVertex3f( 0.38f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f( 0.565f, 0.55f, 0.62f); glVertex3f( 0.565f, 0.95f, 0.62f);
        glVertex3f( 0.38f,  0.75f, 0.62f); glVertex3f( 0.75f,  0.75f, 0.62f);
    glEnd();

    GLfloat RF[2][3] = { { 0.0f, 1.8f,  0.7f}, { 0.0f, 1.8f, -0.7f} };
    GLfloat RE[4][3] = {
        {-1.1f, 1.2f,  0.7f}, { 1.1f, 1.2f,  0.7f},
        { 1.1f, 1.2f, -0.7f}, {-1.1f, 1.2f, -0.7f},
    };
    glColor3f(0.72f, 0.19f, 0.15f);
    Face(RE[0], RE[3], RF[1], RF[0]);
    Face(RE[1], RE[2], RF[1], RF[0]);
    Triangle(RE[0], RE[1], RF[0]);
    Triangle(RE[3], RE[2], RF[1]);
}
void DrawHouseKeyed() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(0, 0, -4.0f);

    if (axis == 0) glRotatef(d, 0, 0, 1);
    else if (axis == 1) glRotatef(d, 1, 0, 0);
    else glRotatef(d, 0, 1, 0);

    glRotatef(15, 1, 0, 0);
    glTranslatef(0, -0.6f, 0);
    DrawHouse();
    glutSwapBuffers();
}

int main(int argc, char *argv [])
{
    glutInit(&argc,argv);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(50,150);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("Spin Cube with Matrices - v2");
    CustomFunction();
    glutReshapeFunc(Reshape);
    glutDisplayFunc(DrawHouseKeyed);
    glutIdleFunc(Spin);
    glutKeyboardFunc(Keyboard);
    glutMainLoop();
    return 0;
}


