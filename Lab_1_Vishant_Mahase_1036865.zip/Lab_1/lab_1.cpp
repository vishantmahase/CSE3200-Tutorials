#include<GL/glu.h> //You must include the necessary libraries to make use of their functions.
#include<GL/glut.h>
#include<windows.h>

//Vishant Mahase
//1036865
//lab 1
//Definition of the display callback function.
void MyFunction()
{
   glClearColor(0,0,0,1);
   glColor3f(0,0,1);
}


void Display()
{
            //This clears the buffer before applying any declared color functions.
    /*9*/glClear(GL_COLOR_BUFFER_BIT);
            //Once the display is cleared, to put your graphics into the frame buffer, make use of:
            //glFlush should always be your last function in the draw function.




            //Grouping the points.
    /*11.1*/ //glBegin(GL_POINTS);   //GL_POINTS is a graphical primitive.
    /*11.2*/  //glBegin(GL_LINES);    //Alternatively lines can be used instead of points.
                                    //This will combine the first and second points to make one line and the 3rd and 4th to make another line.
    /*11.3*/  //glBegin(GL_LINE_LOOP); // Alternatively, the points can be looped together to form an enclosed figure.
    /*11.4*/  //Declaring points.

            //square 1
            glColor3f(0,0,1);
        glBegin(GL_POLYGON); //You may also make use of polygons to have a filled object.
            glVertex2f(-0.9,0.8);
            glVertex2f(-0.7,0.8);
            glVertex2f(-0.7,0.6);
            glVertex2f(-0.9,0.6);
            glEnd();

            //square 2
            glColor3f(1,0,0);
        glBegin(GL_POLYGON); //You may also make use of polygons to have a filled object.
            glVertex2f(-0.6,0.8);
            glVertex2f(-0.4,0.8);
            glVertex2f(-0.4,0.6);
            glVertex2f(-0.6,0.6);
            glEnd();



    // triangle
    glColor3f(1,1,0);
    glBegin(GL_TRIANGLES);
        glVertex2f(0.4,0.8);
        glVertex2f(0.3,0.6);
        glVertex2f(0.5,0.6);
    glEnd();

    // square using two triangles
    glColor3f(0,1,1);
    glBegin(GL_TRIANGLES);

        glVertex2f(-0.8,0.3);
        glVertex2f(-0.6,0.3);
        glVertex2f(-0.6,0.1);

        glVertex2f(-0.8,0.3);
        glVertex2f(-0.6,0.1);
        glVertex2f(-0.8,0.1);

    glEnd();

    // pentagon
    glColor3f(1,0,1);
    glBegin(GL_POLYGON);
        glVertex2f(-0.3,0.3);
        glVertex2f(-0.4,0.15);
        glVertex2f(-0.35,0.0);
        glVertex2f(-0.25,0.0);
        glVertex2f(-0.2,0.15);
    glEnd();

    // hexagon
    glColor3f(0.5,0.5,1);
    glBegin(GL_POLYGON);
        glVertex2f(0.0,0.3);
        glVertex2f(0.1,0.2);
        glVertex2f(0.1,0.05);
        glVertex2f(0.0,-0.05);
        glVertex2f(-0.1,0.05);
        glVertex2f(-0.1,0.2);
    glEnd();

    // heptagon
    glColor3f(1,0.5,0);
    glBegin(GL_POLYGON);
        glVertex2f(0.4,0.3);
        glVertex2f(0.5,0.2);
        glVertex2f(0.45,0.05);
        glVertex2f(0.35,-0.05);
        glVertex2f(0.25,0.05);
        glVertex2f(0.25,0.2);
        glVertex2f(0.3,0.3);
    glEnd();

    // octagon
    glColor3f(0.3,1,0.5);
    glBegin(GL_POLYGON);
        glVertex2f(-0.7,-0.2);
        glVertex2f(-0.6,-0.1);
        glVertex2f(-0.5,-0.1);
        glVertex2f(-0.4,-0.2);
        glVertex2f(-0.4,-0.3);
        glVertex2f(-0.5,-0.4);
        glVertex2f(-0.6,-0.4);
        glVertex2f(-0.7,-0.3);
    glEnd();

    // decagon
    glColor3f(0.8,0.3,0.8);
    glBegin(GL_POLYGON);
        glVertex2f(0.1,-0.2);
        glVertex2f(0.2,-0.1);
        glVertex2f(0.3,-0.1);
        glVertex2f(0.4,-0.2);
        glVertex2f(0.45,-0.3);
        glVertex2f(0.4,-0.4);
        glVertex2f(0.3,-0.45);
        glVertex2f(0.2,-0.45);
        glVertex2f(0.1,-0.4);
        glVertex2f(0.05,-0.3);
    glEnd();



    /*10*/glFlush(); //Sends the declared graphics to the buffer to be rendered.
}




int main(int C, char *V[])
//The second function is a multi-string array.
{
            //Any C program is compiled in the console.
            //Hence an API is needed to convert console based code to a graphical window.


     /*1*/ glutInit(&C,V);


          //This is the first API being used. This allows graphical output to be printed in a window.
         //This function takes 2 parameters from the main function. These parameters are command line arguments.


         //Repositioning the window.
         //This is based on the position on the x,y axis.
     /*6*/ glutInitWindowPosition(250,50);


         //Modifying the size of the window.
         //The two arguments specifies the Width and height of the rendered window.
    /*5*/ glutInitWindowSize(600,600);


        //Display mode for the graphical window - RGB.
        //This function makes use a single buffer and the RGB color mode.
        //The single buffer is applicable in a 2D environment.
        //Once a 3D render is needed, a second/ double buffer will be needed.
    /*7*/glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);




    /*2*/ glutCreateWindow("First Program.");
        //Takes one argument - The title of the window.


        //Changing the background color of the graphical window.


    /*8*//*glClearColor(0,0,0,1); //The final parameter is the transparency parameter.
         glColor3f(1,0,0); */


         //Generally these customizations should be managed in a separate function.
         //REFER TO MyFunction above.


              MyFunction();


        //To ensure the graphical window remains active, you must include a display callback function.
    /*4*/ glutDisplayFunc(Display);
        //Function is declared before the main function.






       //To see the graphical window use:
    /*3*/ glutMainLoop();


   return 0;
}





