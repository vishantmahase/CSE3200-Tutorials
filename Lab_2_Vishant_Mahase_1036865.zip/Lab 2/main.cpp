//Vishant Mahase
//1036865
//lab 2
#include<GL/glu.h>
#include<GL/glut.h>
#include<windows.h>

//Rotation Variable.
GLfloat T = 0;

//Spin function
void Spin(){
    T = T + 0.1;            //Increments the current position of the rotation by 1
    if (T > 360)            //Sets a stop condition.
        T = 0;
    glutPostRedisplay();    //Resets the render once 360 degree rotation is met.
}

void MyFunction3()
{
   glClearColor(0.53f, 0.81f, 0.92f, 1);
   glColor3f(0,1,0);
   //Without this function, the back buffer/ z-buffer will not be activated and you will not see the front face of the cube.
   glEnable(GL_DEPTH_TEST);
}

//This custom function draws a face of the cube.
//Each face of the cube will contain 4 points, hence 4 points need to be called within its function.
Face(GLfloat A[],GLfloat B[], GLfloat C[], GLfloat D[])
{
    glBegin(GL_POLYGON);
            glVertex3f(A[0],A[1],A[2]); // Alternatively you can pass each value one by one.
            glVertex3fv(B);             //By specifying v in the function, the entire array can be passed.
            glVertex3fv(C);
            glVertex3fv(D);
    glEnd();

}

     void Triangle(GLfloat A[], GLfloat B[], GLfloat C[]) {
    glBegin(GL_TRIANGLES);
        glVertex3fv(A);
        glVertex3fv(B);
        glVertex3fv(C);
    glEnd();
}

void DrawHouse() {
    GLfloat V[8][3] = {
        {-1.0f,  0.0f,  0.6f},
        { 1.0f,  0.0f,  0.6f},
        { 1.0f,  1.2f,  0.6f},
        {-1.0f,  1.2f,  0.6f},
        {-1.0f,  0.0f, -0.6f},
        { 1.0f,  0.0f, -0.6f},
        { 1.0f,  1.2f, -0.6f},
        {-1.0f,  1.2f, -0.6f},
    };

    // Walls
    glColor3f(0.91f, 0.76f, 0.57f);
    Face(V[0], V[1], V[2], V[3]); // front
    Face(V[5], V[4], V[7], V[6]); // back
    Face(V[4], V[0], V[3], V[7]); // left
    Face(V[1], V[5], V[6], V[2]); // right
    glColor3f(0.6f, 0.5f, 0.4f);
    Face(V[4], V[5], V[1], V[0]); // floor

    // Door
    glColor3f(0.36f, 0.20f, 0.09f);
    GLfloat D[4][3] = {
        {-0.18f, 0.0f,  0.61f},
        { 0.18f, 0.0f,  0.61f},
        { 0.18f, 0.60f, 0.61f},
        {-0.18f, 0.60f, 0.61f},
    };
    Face(D[0], D[1], D[2], D[3]);
    glColor3f(1.0f, 0.84f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex3f(0.14f, 0.30f, 0.62f);
    glEnd();

    // Window Left
    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WL[4][3] = {
        {-0.75f, 0.55f, 0.61f},
        {-0.38f, 0.55f, 0.61f},
        {-0.38f, 0.95f, 0.61f},
        {-0.75f, 0.95f, 0.61f},
    };
    Face(WL[0], WL[1], WL[2], WL[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f(-0.75f, 0.55f, 0.62f); glVertex3f(-0.38f, 0.55f, 0.62f);
        glVertex3f(-0.38f, 0.95f, 0.62f); glVertex3f(-0.75f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f(-0.565f, 0.55f, 0.62f); glVertex3f(-0.565f, 0.95f, 0.62f);
        glVertex3f(-0.75f,  0.75f, 0.62f); glVertex3f(-0.38f,  0.75f, 0.62f);
    glEnd();

    // Window Right
    glColor3f(0.68f, 0.85f, 0.90f);
    GLfloat WR[4][3] = {
        { 0.38f, 0.55f, 0.61f},
        { 0.75f, 0.55f, 0.61f},
        { 0.75f, 0.95f, 0.61f},
        { 0.38f, 0.95f, 0.61f},
    };
    Face(WR[0], WR[1], WR[2], WR[3]);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_LINE_LOOP);
        glVertex3f( 0.38f, 0.55f, 0.62f); glVertex3f( 0.75f, 0.55f, 0.62f);
        glVertex3f( 0.75f, 0.95f, 0.62f); glVertex3f( 0.38f, 0.95f, 0.62f);
    glEnd();
    glBegin(GL_LINES);
        glVertex3f( 0.565f, 0.55f, 0.62f); glVertex3f( 0.565f, 0.95f, 0.62f);
        glVertex3f( 0.38f,  0.75f, 0.62f); glVertex3f( 0.75f,  0.75f, 0.62f);
    glEnd();

    // Roof
    GLfloat RF[2][3] = { { 0.0f, 1.8f,  0.7f}, { 0.0f, 1.8f, -0.7f} };
    GLfloat RE[4][3] = {
        {-1.1f, 1.2f,  0.7f}, { 1.1f, 1.2f,  0.7f},
        { 1.1f, 1.2f, -0.7f}, {-1.1f, 1.2f, -0.7f},
    };
    glColor3f(0.72f, 0.19f, 0.15f);
    Face(RE[0], RE[3], RF[1], RF[0]); // left slope
    Face(RE[1], RE[2], RF[1], RF[0]); // right slope
    Triangle(RE[0], RE[1], RF[0]);    // front
    Triangle(RE[3], RE[2], RF[1]);    // back
}

void Display3() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glRotatef(T, 0, 1, 0);
    glRotatef(15, 1, 0, 0);
    glTranslatef(0, -0.6f, 0);
    DrawHouse();
    glutSwapBuffers();
}


// External function which calls on the specific vertices to be drawn.
void Cube(GLfloat V0[],
          GLfloat V1[],
          GLfloat V2[],
          GLfloat V3[],
          GLfloat V4[],
          GLfloat V5[],
          GLfloat V6[],
          GLfloat V7[]
          )
          {
              glColor3f(1,0,0);     //color the front face red
              Face(V0, V1, V2, V3);
              glColor3f(0,0,1);     //color the back face green.
              Face(V4, V5, V6, V7);
              glColor3f(0,1,0);     //Left Face
              Face(V0, V3, V7, V4);
              glColor3f(1,0,1);     //Right Face
              Face(V1, V2, V6, V5);
              glColor3f(1,1,0);     // Top Face
              Face(V0, V1, V5, V4);
              glColor3f(0,1,1);
              Face(V3, V2, V6, V7); // Bottom Face
          }



int main(int C, char *V[])
{
    glutInit(&C,V);
    glutInitWindowPosition(250,50);
    glutInitWindowSize(600,600);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("Lab 2 - Spinning a Cube");
    MyFunction3();
    glutDisplayFunc(Display3);
    //Whenever the code is rendered, and is idle, this function will spin the object specified.
    glutIdleFunc(Spin);
    glutMainLoop();

    return 0;
}


